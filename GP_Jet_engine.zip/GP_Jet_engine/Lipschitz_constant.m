clc;
clear all;

syms x1 x2

f1=-x2-3/2*x1^2-1/2*x1^3;
f2=x1;

A1=[diff(f1,x1) diff(f1,x2)];
A2=[diff(f2,x1) diff(f2,x2)];

nA1=norm(A1,inf)
nA2=norm(A2,inf)

x=-1:0.000001:3;
%y=(abs((3*x.^2)/2 + 3.*x).^2 + 1).^(1/2);   %using norm2
for i=1:length(x)
    y(1,i)=max(abs((3*x(i)^2)/2 + 3*x(i)), 1);
end
L1=max(y)
L2=1