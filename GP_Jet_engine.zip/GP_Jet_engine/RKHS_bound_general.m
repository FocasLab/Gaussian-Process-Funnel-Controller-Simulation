clc;
clear all;
%%
% M{1,1}=trn_x; M{2,1}=trn_f; M{3,1}=[l11 l12 sigma1] (kernal1 parameters);
% M{4,1}=[l21 l22 sigma1] (kernal2 parameters); M{5,1}=stdmax;
load('Data25.mat')

%%
%\partial k(x1,x2)/\partial x1 =-\Lambda^{-1} (x1-x2)k(x1,x2) 
%\partial k(x1,x2)/\partial x2 =\Lambda^{-1} (x1-x2)k(x1,x2) 

%Lipschitz constants from Lipschitz_constant.m
L1 =22.5000
L2 =1
invL1=inv([M{3,1}(1) 0;0 M{3,1}(2)]);
invL2=inv([M{4,1}(1) 0;0 M{4,1}(2)]);
ssigma1=M{3,1}(3);
ssigma2=M{4,1}(3);

x1=[-1:0.01:3;-4:0.02:4];
k=1;
for i1=1:length(x1)
    for j1=1:length(x1)
        d1(:,k)=invL1*(x1(:,i1)-x1(:,j1))*ssigma1*exp(-1/2*(x1(:,i1)-x1(:,j1))'*invL1*(x1(:,i1)-x1(:,j1)));
        k=k+1;
    end
end
d2=-d1;
for j1=1:length(d1)
    nk1(1,j1)=norm([d2(:,j1) d1(:,j1)],inf);
end
dk1_inf=max(nk1)

k=1;
for i1=1:length(x1)
    for j1=1:length(x1)
        dd1(:,k)=invL2*(x1(:,i1)-x1(:,j1))*ssigma2*exp(-1/2*(x1(:,i1)-x1(:,j1))'*invL2*(x1(:,i1)-x1(:,j1)));
        k=k+1;
    end
end
dd2=-dd1;
for j1=1:length(dd1)
    nk2(1,j1)=norm([dd2(:,j1) dd1(:,j1)],inf);
end
dk2_inf=max(nk2)
%%
% ||k||_\infty:= sup_{x\inX}\sqrt(k(x,x))
for i=1:length(x1)
    k1(1,i)=sqrt(ssigma1*exp(-1/2*(x1(:,i)-x1(:,i))'*invL1*(x1(:,i)-x1(:,i))));
    k2(1,i)=sqrt(ssigma2*exp(-1/2*(x1(:,i)-x1(:,i))'*invL2*(x1(:,i)-x1(:,i))));
end
k1_inf=max(k1);
k2_inf=max(k2);

%%
% bound on RKHS
B1=L1^2/(2*k1_inf*dk1_inf)
B2=L2^2/(2*k2_inf*dk2_inf)
