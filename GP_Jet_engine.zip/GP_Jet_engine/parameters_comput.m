eps1=3;
eps2=1.5;

l11=gprModels{1, 1}.KernelInformation.KernelParameters(1);
l12=gprModels{1, 1}.KernelInformation.KernelParameters(2);
l21=gprModels{2, 1}.KernelInformation.KernelParameters(1);
l22=gprModels{2, 1}.KernelInformation.KernelParameters(2);
sigma1=gprModels{1, 1}.KernelInformation.KernelParameters(3)
xxx=sigma1*(2*pi*(l11+l22)/2)^(-1)

yyy=(l11+l22)/8

