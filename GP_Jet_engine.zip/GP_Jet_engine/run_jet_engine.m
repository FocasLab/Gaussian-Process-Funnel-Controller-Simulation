clear; close all; clc; %rng default;
p_lb=[];
p_ub=[]; 
std=[];
M=1;    %number of multiple runs for montecarlo bound
%% Set parameters
for k=1:M      
    t=1;
    trn_f=[];
    trn_x=[];
    %for N=20:5:100    %To run it for different values of N
    for N=25
        % Dynamics

        E = 2;                       % Dimensions of the state space  
        sn = 1e-2*[1 1]';            % Observation noise (default = 1e-2)
        %dynt = @(t,x) dyn2D(0,x);    % dynamical system to be controlled
        %dyn = @(x) dynt(0,x);        % time independent handle to dynamics

        % GP learning
        optGPR = {'FitMethod','exact','ConstantSigma',true,'Sigma',sn,...
            'KernelFunction','ardsquaredexponential' };

        % Visualization
        Ngrid = 5*1e4;                % Number of gridpoints (default = 1e4)
        grid_min = [-1;-4]; grid_max = [3;4];
        Nte = 5*1e4;                  % Number of points for visualization (default = 1e4)
        gmte = 1;                   % Grid margin outside of training points
        grid_minte = grid_min; grid_maxte = grid_max;
        Ndte = floor(nthroot(Nte,E)); % Nte = Ndte^E;
        Xte = ndgridj(grid_minte, grid_maxte,Ndte*ones(E,1)) ;
        Xte1 = reshape(Xte(1,:),Ndte,Ndte); Xte2 = reshape(Xte(2,:),Ndte,Ndte);

        %% Generating data points
        trn_x=[-1+4*rand(1,N); -3+6*rand(1,N)];
        for i=1:size(trn_x,2)
            trn_f(1,i)=-trn_x(2,i)-3/2*trn_x(1,i)^2-1/2*trn_x(1,i)^3+1e-4*randn(1);
            trn_f(2,i)=trn_x(1,i)+1e-4*randn(1);
        end
        
        %% Learn GPSSM
        disp('Learn GPSSM...')

        [mufun,varfun,gprModels] = learnGPR(trn_x,trn_f,optGPR{:});

        stdmax = max(sqrt(max(varfun(Xte).^2)))

        % %% Generate Trajectories
        % disp('Run Simulation...')
        % 
        % fun = @(x) mufun(x);
        % [Ttraj,Xtraj]  = ode45(fun,[0 1],[2,1]);
        xfnm1 = sprintf ('Data%d.mat',N);
        M = cell (5, 1);
        M{1}=trn_x;
        M{2}=trn_f;
        M{3}=gprModels{1, 1}.KernelInformation.KernelParameters;
        M{4}=gprModels{2, 1}.KernelInformation.KernelParameters;
        M{5}=stdmax;
        save(xfnm1,'M');
        %% Visualization
        disp('Visualize...')

%         figure; hold on; axis tight;
%         title('GPSSM: Mean and Variance Prediction')
%         surf(Xte1,Xte2,reshape(sqrt(sum(varfun(Xte).^2))-1e4,Ndte,Ndte),'EdgeColor','none','FaceColor','interp'); colormap(flipud(parula))
%         colorbar
         Xte_vec = mufun(Xte);
         Xte_vec1 = [-Xte(2,:)-3/2*Xte(1,:).^2-1/2*Xte(1,:).^3;Xte(1,:)];
%         hold on;
%         h = streamslice(Xte1,Xte2,reshape(Xte_vec(1,:),Ndte,Ndte),reshape(Xte_vec(2,:),Ndte,Ndte),2,'r'); set( h, 'Color', 'r' );
%         figure(2);
%         h2= streamslice(Xte1,Xte2,reshape(Xte_vec1(1,:),Ndte,Ndte),reshape(Xte_vec1(2,:),Ndte,Ndte),2,'b'); set( h, 'Color', 'b' );
        % hold on;
        % plot(Xtraj(:,1),Xtraj(:,2),'r');

        %% Binomial proportion confidence interval
%         error1=Xte_vec(1,:)-Xte_vec1(1,:);
%         error2=Xte_vec(2,:)-Xte_vec1(2,:);
%         std(k,t)=stdmax;
%         beta=0.05/stdmax;
%         s1=sum(abs(error1)>stdmax*beta);
%         s2=sum(abs(error2)>stdmax*beta);
%         n=length(Xte_vec);
%         nf=(s1+s2);
%         ns=n-(s1+s2);
%         prob= (s1+s2)/length(Xte_vec);
%         alpha=1e-10;
%         z=sqrt(2)*erfinv(2*(1-alpha/2)-1);
%         prob_bound=[ns/n-z/n*sqrt(ns*nf/n), ns/n+z/n*sqrt(ns*nf/n)];
%         p_lb(k,t)=prob_bound(1);
%         p_ub(k,t)=prob_bound(2);
%         t=t+1;
    end  
end
%%plotting bounds for different values of N

% p_ub_f=sum(p_ub,1)/50
% p_lb_f=sum(p_lb,1)/50
% std_f=sum(std,1)/50
% figure(1);
% plot([20:5:100],p_lb_f);
% figure(2);
% plot([20:5:100],std_f);
% figure(3);
% plot([20:5:100],p_ub_f);
% figure(4)
% semilogy([20:5:100],p_lb_f);
% figure(5);
% semilogy([20:5:100],std_f);
% figure(6);
% semilogy([20:5:100],p_ub_f);